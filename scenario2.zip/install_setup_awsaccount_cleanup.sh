#!/usr/bin/env bash
mkdir awsweeper
curl -sSfL https://raw.githubusercontent.com/jckuester/awsweeper/master/install.sh | sh -s v0.11.1
awsweeper --profile myaccount AWS_DEFAULT_REGION=us-west-2 config.yml
