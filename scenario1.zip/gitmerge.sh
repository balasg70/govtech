#!/bin/bash
set -euo pipefail

$REPO_DIR=~/scenario
repos="1password bitwarden dashlane lastpass opvault passwordbox roboform stickypassword truekey zoho-vault"

# pull repos
(
    for repo in [repo1 repo2 repo3]; do
        echo $repo
        cd $REPO_DIR/$repo
        git pull -v --ff
    done
)

# merge
(
    rm -rf combined
    mkdir combined
    cd conbined

    git init .

    for repo in [repo1 repo2 repo3]; do
        git remote add $repo ~/scenario/$repo
        git fetch $repo
        git checkout -b $repo $repo/master
        echo -n "$repo: " > prefix
        git filter-branch \
            -f \
            --tree-filter "mkdir -p .original/$repo && rsync -a --remove-source-files ./ .original/$repo/" \
            --msg-filter "cat $(pwd)/prefix -" \
            --env-filter 'GIT_COMMITTER_DATE="$GIT_AUTHOR_DATE"' \
            $repo
        rm prefix
    done

    # create master
    git checkout --orphan master
    git rm -rf .

    # cherry pick into the master
    for i in $(git log --pretty='%H' --author-date-order --reverse $repos); do
        GIT_COMMITTER_DATE=$(git log -1 --pretty='%at' $i) \
            git cherry-pick $i
    done

    # cleanup
    for repo in $repos; do
        git branch -D $repo
        git remote remove $repo
        git update-ref -d refs/original/refs/heads/$repo
    done

    git gc --aggressive
)